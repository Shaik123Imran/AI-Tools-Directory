import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, ExternalLink } from "lucide-react"
import { mockTools } from "@/lib/mock-data"

export function TrendingTools() {
  // Get top rated tools as "trending"
  const trendingTools = mockTools
    .filter((tool) => tool.rating && tool.rating >= 4.4)
    .sort((a, b) => (b.rating || 0) - (a.rating || 0))
    .slice(0, 5)

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <TrendingUp className="h-6 w-6 text-primary" />
            <h2 className="text-3xl font-bold">Trending This Week</h2>
          </div>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            The most popular AI tools that are making waves in the community
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
          {trendingTools.map((tool, index) => (
            <Card
              key={tool.id}
              className="hover:shadow-lg transition-all duration-300 hover:-translate-y-1 relative overflow-hidden"
            >
              <div className="absolute top-2 left-2 z-10">
                <Badge variant="secondary" className="text-xs">
                  #{index + 1}
                </Badge>
              </div>

              <CardHeader className="pb-2 pt-8">
                <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-lg flex items-center justify-center mb-2">
                  <span className="text-lg font-bold text-primary">{tool.name.charAt(0)}</span>
                </div>
                <CardTitle className="text-lg leading-tight">{tool.name}</CardTitle>
              </CardHeader>

              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground line-clamp-2">{tool.short_description}</p>

                <div className="flex items-center justify-between">
                  <Badge variant="outline" className="text-xs">
                    {tool.pricing}
                  </Badge>
                  <div className="flex items-center space-x-1">
                    <span className="text-sm font-medium">⭐ {tool.rating}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <Link href={`/tool/${tool.slug}`} className="text-sm font-medium text-primary hover:underline">
                    Learn More
                  </Link>
                  <Link
                    href={tool.website_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-primary"
                  >
                    <ExternalLink className="h-3 w-3" />
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
