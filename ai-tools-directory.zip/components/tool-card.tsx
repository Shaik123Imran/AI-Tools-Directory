import Link from "next/link"
import Image from "next/image"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Star, ExternalLink, TrendingUp, Users } from "lucide-react"
import type { Database } from "@/lib/supabase"

type Tool = Database["public"]["Tables"]["tools"]["Row"] & {
  categories?: Database["public"]["Tables"]["categories"]["Row"]
}

interface ToolCardProps {
  tool: Tool
  variant?: "default" | "compact" | "featured"
}

export function ToolCard({ tool, variant = "default" }: ToolCardProps) {
  const getPricingColor = (pricing: string) => {
    switch (pricing) {
      case "Free":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "Freemium":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      case "Paid":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
    }
  }

  if (variant === "compact") {
    return (
      <Card className="group hover:shadow-md transition-all duration-300">
        <CardContent className="p-4">
          <div className="flex items-center space-x-3">
            {tool.logo_url && (
              <Image
                src={tool.logo_url || "/placeholder.svg"}
                alt={`${tool.name} logo`}
                width={32}
                height={32}
                className="rounded-lg"
              />
            )}
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold truncate group-hover:text-primary transition-colors">{tool.name}</h3>
              <p className="text-sm text-muted-foreground truncate">{tool.short_description}</p>
            </div>
            <Badge className={getPricingColor(tool.pricing)} variant="secondary">
              {tool.pricing}
            </Badge>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (variant === "featured") {
    return (
      <Card className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-2 relative overflow-hidden">
        <div className="absolute top-4 right-4 z-10">
          <Badge className="bg-gradient-to-r from-yellow-400 to-orange-400 text-black">
            <TrendingUp className="h-3 w-3 mr-1" />
            Featured
          </Badge>
        </div>

        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-4">
              {tool.logo_url && (
                <div className="relative">
                  <Image
                    src={tool.logo_url || "/placeholder.svg"}
                    alt={`${tool.name} logo`}
                    width={56}
                    height={56}
                    className="rounded-xl"
                  />
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white" />
                </div>
              )}
              <div>
                <CardTitle className="text-xl group-hover:text-primary transition-colors">{tool.name}</CardTitle>
                {tool.rating && (
                  <div className="flex items-center space-x-1 mt-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium">{tool.rating}</span>
                    <span className="text-xs text-muted-foreground">• 1.2k reviews</span>
                  </div>
                )}
              </div>
            </div>
            <Badge className={getPricingColor(tool.pricing)}>{tool.pricing}</Badge>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          <CardDescription className="line-clamp-2 text-base leading-relaxed">
            {tool.short_description || tool.description}
          </CardDescription>

          {tool.tags && tool.tags.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {tool.tags.slice(0, 3).map((tag) => (
                <Badge key={tag} variant="secondary" className="text-xs">
                  {tag}
                </Badge>
              ))}
              {tool.tags.length > 3 && (
                <Badge variant="secondary" className="text-xs">
                  +{tool.tags.length - 3}
                </Badge>
              )}
            </div>
          )}

          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Users className="h-3 w-3" />
              <span>2.1k users</span>
            </div>
            <div className="flex items-center space-x-2">
              <Button asChild variant="outline" size="sm">
                <Link href={`/tool/${tool.slug}`}>Learn More</Link>
              </Button>
              <Button asChild size="sm">
                <Link href={tool.website_url} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-3 w-3 mr-1" />
                  Try Now
                </Link>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Default variant
  return (
    <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            {tool.logo_url && (
              <Image
                src={tool.logo_url || "/placeholder.svg"}
                alt={`${tool.name} logo`}
                width={48}
                height={48}
                className="rounded-lg"
              />
            )}
            <div>
              <CardTitle className="text-lg group-hover:text-primary transition-colors">{tool.name}</CardTitle>
              {tool.rating && (
                <div className="flex items-center space-x-1 mt-1">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm text-muted-foreground">{tool.rating}</span>
                </div>
              )}
            </div>
          </div>
          <Badge className={getPricingColor(tool.pricing)}>{tool.pricing}</Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <CardDescription className="line-clamp-2">{tool.short_description || tool.description}</CardDescription>

        {tool.tags && tool.tags.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {tool.tags.slice(0, 3).map((tag) => (
              <Badge key={tag} variant="secondary" className="text-xs">
                {tag}
              </Badge>
            ))}
            {tool.tags.length > 3 && (
              <Badge variant="secondary" className="text-xs">
                +{tool.tags.length - 3}
              </Badge>
            )}
          </div>
        )}

        <div className="flex items-center justify-between pt-2">
          <Link href={`/tool/${tool.slug}`} className="text-sm font-medium text-primary hover:underline">
            Learn More
          </Link>
          <Link
            href={tool.website_url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center space-x-1 text-sm text-muted-foreground hover:text-primary"
          >
            <ExternalLink className="h-3 w-3" />
            <span>Visit</span>
          </Link>
        </div>
      </CardContent>
    </Card>
  )
}
