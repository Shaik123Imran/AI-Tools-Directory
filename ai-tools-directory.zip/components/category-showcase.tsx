import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowRight } from "lucide-react"
import { mockCategories, mockTools } from "@/lib/mock-data"
import {
  Code,
  Zap,
  Search,
  Palette,
  PenTool,
  BarChart3,
  GraduationCap,
  Briefcase,
  ImageIcon,
  Music,
} from "lucide-react"

const iconMap = {
  Code: Code,
  Zap: Zap,
  Search: Search,
  Palette: Palette,
  PenTool: PenTool,
  BarChart3: BarChart3,
  GraduationCap: GraduationCap,
  Briefcase: Briefcase,
  ImageIcon: ImageIcon,
  Music: Music,
}

export function CategoryShowcase() {
  const categoriesWithCounts = mockCategories.map((category) => {
    const toolCount = mockTools.filter((tool) => tool.category_id === category.id).length
    return {
      ...category,
      toolCount,
    }
  })

  // Show top 8 categories
  const topCategories = categoriesWithCounts.slice(0, 8)

  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Explore by Category</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Find the perfect AI tool for your specific needs across different domains
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {topCategories.map((category) => {
            const IconComponent = iconMap[category.icon as keyof typeof iconMap] || Code

            return (
              <Link key={category.id} href={`/tools?category=${category.slug}`}>
                <Card className="hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer group">
                  <CardHeader className="text-center pb-2">
                    <div className="mx-auto mb-3 p-4 bg-primary/10 rounded-xl w-fit group-hover:bg-primary/20 transition-colors">
                      <IconComponent className="h-8 w-8 text-primary" />
                    </div>
                    <CardTitle className="text-lg">{category.name}</CardTitle>
                    <Badge variant="secondary" className="mx-auto w-fit">
                      {category.toolCount} tools
                    </Badge>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <CardDescription className="text-center text-sm leading-relaxed">
                      {category.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              </Link>
            )
          })}
        </div>

        <div className="text-center">
          <Link href="/categories" className="inline-flex items-center text-primary hover:underline font-medium">
            View All Categories
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  )
}
