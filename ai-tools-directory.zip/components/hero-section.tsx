"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { ArrowRight, Sparkles, Search, TrendingUp, Users, Zap } from "lucide-react"

const stats = [
  { icon: Zap, label: "AI Tools", value: "500+" },
  { icon: Users, label: "Happy Users", value: "50K+" },
  { icon: TrendingUp, label: "Categories", value: "15+" },
]

const trendingSearches = ["GitHub Copilot", "ChatGPT", "Midjourney", "Claude", "Perplexity AI"]

export function HeroSection() {
  const [searchQuery, setSearchQuery] = useState("")
  const [currentTrend, setCurrentTrend] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTrend((prev) => (prev + 1) % trendingSearches.length)
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      window.location.href = `/tools?search=${encodeURIComponent(searchQuery)}`
    }
  }

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-primary/5 via-background to-secondary/5">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-grid-pattern opacity-5" />

      <div className="container mx-auto px-4 py-20 lg:py-32 relative">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          {/* Badge */}
          <div className="flex justify-center">
            <Badge className="mb-4 px-4 py-2 text-sm" variant="secondary">
              <Sparkles className="h-3 w-3 mr-2" />
              Discover AI Tools • Updated Daily
            </Badge>
          </div>

          {/* Main Heading */}
          <div className="space-y-6">
            <h1 className="text-4xl lg:text-7xl font-bold tracking-tight leading-tight">
              Discover the Best{" "}
              <span className="text-primary bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                AI Tools
              </span>{" "}
              for Techies & Students
            </h1>
            <p className="text-xl lg:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              Curated collection of cutting-edge AI tools to boost your productivity, enhance your learning, and
              accelerate your projects. Join thousands of developers and students already using AI to level up.
            </p>
          </div>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto">
            <form onSubmit={handleSearch} className="relative">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
                <Input
                  type="text"
                  placeholder={`Try "${trendingSearches[currentTrend]}" or search any AI tool...`}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-12 pr-32 py-6 text-lg rounded-full border-2 focus:border-primary transition-colors"
                />
                <Button
                  type="submit"
                  size="lg"
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 rounded-full px-6"
                >
                  Search
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </form>

            {/* Trending Searches */}
            <div className="mt-4 flex flex-wrap justify-center gap-2">
              <span className="text-sm text-muted-foreground">Trending:</span>
              {trendingSearches.slice(0, 3).map((search) => (
                <Link
                  key={search}
                  href={`/tools?search=${encodeURIComponent(search)}`}
                  className="text-sm text-primary hover:underline"
                >
                  {search}
                </Link>
              ))}
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Button asChild size="lg" className="text-lg px-8 py-6 rounded-full">
              <Link href="/tools">
                Explore 500+ Tools
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="text-lg px-8 py-6 rounded-full bg-transparent">
              <Link href="/submit">Submit Your Tool</Link>
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-12 max-w-2xl mx-auto">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center space-y-2">
                <div className="flex items-center justify-center">
                  <stat.icon className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-3xl font-bold">{stat.value}</h3>
                <p className="text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
