"use client"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, X, Filter } from "lucide-react"
import { supabase, isSupabaseConfigured } from "@/lib/supabase"
import { mockCategories } from "@/lib/mock-data"
import type { Database } from "@/lib/supabase"

type Category = Database["public"]["Tables"]["categories"]["Row"]

interface SearchFiltersProps {
  onFiltersChange: (filters: {
    search: string
    category: string
    pricing: string
    sortBy: string
  }) => void
  initialFilters?: {
    search?: string
    category?: string
    pricing?: string
    sortBy?: string
  }
}

export function SearchFilters({ onFiltersChange, initialFilters = {} }: SearchFiltersProps) {
  const [search, setSearch] = useState(initialFilters.search || "")
  const [category, setCategory] = useState(initialFilters.category || "all")
  const [pricing, setPricing] = useState(initialFilters.pricing || "all")
  const [sortBy, setSortBy] = useState(initialFilters.sortBy || "name")
  const [categories, setCategories] = useState<Category[]>([])

  useEffect(() => {
    fetchCategories()
  }, [])

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      onFiltersChange({ search, category, pricing, sortBy })
    }, 300) // Debounce the filter changes

    return () => clearTimeout(timeoutId)
  }, [search, category, pricing, sortBy])

  const fetchCategories = async () => {
    if (isSupabaseConfigured()) {
      const { data } = await supabase.from("categories").select("*").order("name")
      if (data) {
        setCategories(data)
      }
    } else {
      // Use mock data when Supabase is not configured
      setCategories(mockCategories)
    }
  }

  const clearFilters = () => {
    setSearch("")
    setCategory("all")
    setPricing("all")
    setSortBy("name")
  }

  const hasActiveFilters = search || category !== "all" || pricing !== "all" || sortBy !== "name"

  return (
    <div className="space-y-4">
      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
        <Input
          placeholder="Search AI tools..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Filters Row */}
      <div className="flex flex-wrap gap-4 items-center">
        <div className="flex items-center space-x-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium">Filters:</span>
        </div>

        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {categories.map((cat) => (
              <SelectItem key={cat.id} value={cat.slug}>
                {cat.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={pricing} onValueChange={setPricing}>
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="Pricing" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Pricing</SelectItem>
            <SelectItem value="Free">Free</SelectItem>
            <SelectItem value="Freemium">Freemium</SelectItem>
            <SelectItem value="Paid">Paid</SelectItem>
          </SelectContent>
        </Select>

        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="name">Name A-Z</SelectItem>
            <SelectItem value="rating">Rating</SelectItem>
            <SelectItem value="created_at">Latest</SelectItem>
          </SelectContent>
        </Select>

        {hasActiveFilters && (
          <Button
            variant="outline"
            size="sm"
            onClick={clearFilters}
            className="flex items-center space-x-1 bg-transparent"
          >
            <X className="h-3 w-3" />
            <span>Clear</span>
          </Button>
        )}
      </div>

      {/* Active Filters */}
      {hasActiveFilters && (
        <div className="flex flex-wrap gap-2">
          {search && (
            <Badge variant="secondary" className="flex items-center space-x-1">
              <span>Search: {search}</span>
              <X className="h-3 w-3 cursor-pointer" onClick={() => setSearch("")} />
            </Badge>
          )}
          {category !== "all" && (
            <Badge variant="secondary" className="flex items-center space-x-1">
              <span>Category: {categories.find((c) => c.slug === category)?.name}</span>
              <X className="h-3 w-3 cursor-pointer" onClick={() => setCategory("all")} />
            </Badge>
          )}
          {pricing !== "all" && (
            <Badge variant="secondary" className="flex items-center space-x-1">
              <span>Pricing: {pricing}</span>
              <X className="h-3 w-3 cursor-pointer" onClick={() => setPricing("all")} />
            </Badge>
          )}
        </div>
      )}
    </div>
  )
}
