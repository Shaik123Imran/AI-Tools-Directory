-- Insert sample categories
INSERT INTO categories (name, slug, description, icon) VALUES
('Coding', 'coding', 'AI tools for programming and development', 'Code'),
('Productivity', 'productivity', 'Tools to boost your productivity', 'Zap'),
('Research', 'research', 'AI-powered research and analysis tools', 'Search'),
('Design', 'design', 'Creative AI tools for designers', 'Palette'),
('Writing', 'writing', 'AI writing assistants and content creation', 'PenTool'),
('Data Science', 'data-science', 'Machine learning and data analysis tools', 'BarChart3'),
('Education', 'education', 'Learning and educational AI tools', 'GraduationCap'),
('Business', 'business', 'AI tools for business and marketing', 'Briefcase')
ON CONFLICT (slug) DO NOTHING;

-- Insert sample tools
INSERT INTO tools (name, slug, description, short_description, website_url, logo_url, category_id, pricing, rating, tags, features, pros, cons, is_featured, is_approved) VALUES
(
  'GitHub Copilot',
  'github-copilot',
  'GitHub Copilot is an AI pair programmer that helps you write code faster and with less work. It draws context from comments and code to suggest individual lines and whole functions instantly.',
  'AI-powered code completion and suggestions',
  'https://github.com/features/copilot',
  '/placeholder.svg?height=64&width=64',
  (SELECT id FROM categories WHERE slug = 'coding'),
  'Paid',
  4.5,
  ARRAY['Code Completion', 'AI Assistant', 'IDE Integration'],
  ARRAY['Real-time code suggestions', 'Multiple language support', 'Context-aware completions', 'IDE integrations'],
  ARRAY['Significantly speeds up coding', 'Learns from your coding style', 'Great for boilerplate code', 'Excellent IDE integration'],
  ARRAY['Requires subscription', 'Sometimes suggests incorrect code', 'Can make developers over-reliant'],
  true,
  true
),
(
  'ChatGPT',
  'chatgpt',
  'ChatGPT is a conversational AI model that can assist with a wide range of tasks including writing, coding, analysis, and creative projects.',
  'Versatile AI assistant for various tasks',
  'https://chat.openai.com',
  '/placeholder.svg?height=64&width=64',
  (SELECT id FROM categories WHERE slug = 'productivity'),
  'Freemium',
  4.7,
  ARRAY['Conversational AI', 'Text Generation', 'Code Help'],
  ARRAY['Natural language processing', 'Code generation', 'Creative writing', 'Problem solving'],
  ARRAY['Versatile and helpful', 'Great for brainstorming', 'Excellent at explanations', 'Free tier available'],
  ARRAY['Can provide incorrect information', 'Limited real-time data', 'Usage limits on free tier'],
  true,
  true
),
(
  'Notion AI',
  'notion-ai',
  'Notion AI helps you write, brainstorm, edit, summarize and translate right inside Notion. It''s integrated seamlessly into your workspace.',
  'AI writing assistant integrated into Notion',
  'https://www.notion.so/product/ai',
  '/placeholder.svg?height=64&width=64',
  (SELECT id FROM categories WHERE slug = 'writing'),
  'Freemium',
  4.3,
  ARRAY['Writing Assistant', 'Productivity', 'Note Taking'],
  ARRAY['Content generation', 'Text summarization', 'Translation', 'Brainstorming'],
  ARRAY['Seamless Notion integration', 'Multiple AI functions', 'Good for content creation'],
  ARRAY['Requires Notion subscription', 'Limited compared to dedicated AI tools'],
  true,
  true
),
(
  'Figma AI',
  'figma-ai',
  'AI-powered design tools within Figma to help designers create, iterate, and improve their designs faster.',
  'AI design assistance in Figma',
  'https://www.figma.com',
  '/placeholder.svg?height=64&width=64',
  (SELECT id FROM categories WHERE slug = 'design'),
  'Freemium',
  4.2,
  ARRAY['Design', 'UI/UX', 'Prototyping'],
  ARRAY['Auto-layout suggestions', 'Color palette generation', 'Design system assistance'],
  ARRAY['Integrated into popular design tool', 'Speeds up design process', 'Good for beginners'],
  ARRAY['Still in development', 'Limited AI features currently'],
  false,
  true
);
