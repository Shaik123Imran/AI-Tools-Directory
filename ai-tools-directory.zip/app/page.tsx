import { HeroSection } from "@/components/hero-section"
import { TrendingTools } from "@/components/trending-tools"
import { CategoryShowcase } from "@/components/category-showcase"
import { TestimonialsSection } from "@/components/testimonials-section"
import { NewsletterSection } from "@/components/newsletter-section"
import { ToolCard } from "@/components/tool-card"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Sparkles } from "lucide-react"
import Link from "next/link"
import { supabase, isSupabaseConfigured } from "@/lib/supabase"
import { mockTools } from "@/lib/mock-data"

export default async function HomePage() {
  let featuredTools = []

  if (isSupabaseConfigured()) {
    // Fetch featured tools from Supabase
    const { data: supabaseFeaturedTools } = await supabase
      .from("tools")
      .select(`
        *,
        categories (*)
      `)
      .eq("is_featured", true)
      .eq("is_approved", true)
      .limit(6)

    featuredTools = supabaseFeaturedTools || []
  } else {
    // Use mock data when Supabase is not configured
    featuredTools = mockTools.filter((tool) => tool.is_featured).slice(0, 6)
  }

  return (
    <div className="min-h-screen">
      {/* Supabase Configuration Notice */}
      {!isSupabaseConfigured() && (
        <div className="bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 border-b border-yellow-200 dark:border-yellow-800">
          <div className="container mx-auto px-4 py-3">
            <div className="flex items-center justify-center text-sm text-yellow-800 dark:text-yellow-200">
              <Sparkles className="h-4 w-4 mr-2" />
              <span>🚀 Demo mode with sample data • Configure Supabase for full functionality</span>
            </div>
          </div>
        </div>
      )}

      {/* Hero Section */}
      <HeroSection />

      {/* Trending Tools */}
      <TrendingTools />

      {/* Featured Tools */}
      {featuredTools && featuredTools.length > 0 && (
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Featured AI Tools</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Hand-picked tools that are making waves in the AI community
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {featuredTools.map((tool) => (
                <ToolCard key={tool.id} tool={tool} />
              ))}
            </div>

            <div className="text-center">
              <Button asChild variant="outline" size="lg">
                <Link href="/tools">
                  View All 500+ Tools
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      )}

      {/* Categories */}
      <CategoryShowcase />

      {/* Testimonials */}
      <TestimonialsSection />

      {/* Newsletter */}
      <NewsletterSection />

      {/* CTA Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <Card className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground overflow-hidden relative">
            <div className="absolute inset-0 bg-grid-pattern opacity-10" />
            <CardContent className="p-12 text-center relative">
              <Badge className="mb-4 bg-white/20 text-white border-white/30">Join the Community</Badge>
              <h2 className="text-3xl font-bold mb-4">Know an Amazing AI Tool?</h2>
              <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
                Help the community discover new AI tools by submitting your recommendations. Every submission is
                reviewed by our team and featured to thousands of users.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild size="lg" variant="secondary" className="text-lg px-8">
                  <Link href="/submit">
                    Submit a Tool
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="text-lg px-8 bg-transparent border-white/30 text-white hover:bg-white/10"
                >
                  <Link href="/blog">Read Our Blog</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}
