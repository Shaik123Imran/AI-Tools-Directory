import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Toaster } from "@/components/ui/toaster"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "AI Tools Hub - Discover the Best AI Tools for Students & Professionals",
  description:
    "Curated collection of the best AI tools for students and tech professionals. Find coding assistants, productivity tools, research aids, and more.",
  keywords: "AI tools, artificial intelligence, productivity, coding, students, professionals, technology",
  authors: [{ name: "AI Tools Hub Team" }],
  openGraph: {
    title: "AI Tools Hub - Discover the Best AI Tools",
    description: "Curated collection of the best AI tools for students and tech professionals.",
    type: "website",
    locale: "en_US",
  },
  twitter: {
    card: "summary_large_image",
    title: "AI Tools Hub - Discover the Best AI Tools",
    description: "Curated collection of the best AI tools for students and tech professionals.",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          <div className="min-h-screen flex flex-col">
            <Navbar />
            <main className="flex-1">{children}</main>
            <Footer />
          </div>
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  )
}
