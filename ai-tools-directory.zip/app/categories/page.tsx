import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { supabase, isSupabaseConfigured } from "@/lib/supabase"
import { mockCategories, mockTools } from "@/lib/mock-data"
import { Code, Zap, Search, Palette, PenTool, BarChart3, GraduationCap, Briefcase, AlertCircle } from "lucide-react"

const iconMap = {
  Code: Code,
  Zap: Zap,
  Search: Search,
  Palette: Palette,
  PenTool: PenTool,
  BarChart3: BarChart3,
  GraduationCap: GraduationCap,
  Briefcase: Briefcase,
}

export default async function CategoriesPage() {
  let categoriesWithCounts = []

  if (isSupabaseConfigured()) {
    const { data: categories } = await supabase
      .from("categories")
      .select(`
        *,
        tools!inner(count)
      `)
      .order("name")

    // Get tool counts for each category
    categoriesWithCounts = await Promise.all(
      (categories || []).map(async (category) => {
        const { count } = await supabase
          .from("tools")
          .select("*", { count: "exact", head: true })
          .eq("category_id", category.id)
          .eq("is_approved", true)

        return {
          ...category,
          toolCount: count || 0,
        }
      }),
    )
  } else {
    // Use mock data when Supabase is not configured
    categoriesWithCounts = mockCategories.map((category) => {
      const toolCount = mockTools.filter((tool) => tool.category_id === category.id).length
      return {
        ...category,
        toolCount,
      }
    })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">AI Tool Categories</h1>
        <p className="text-muted-foreground">Browse AI tools by category to find exactly what you need</p>
      </div>

      {!isSupabaseConfigured() && (
        <Alert className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Demo mode: Showing sample categories. Configure Supabase to access the full database.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categoriesWithCounts.map((category) => {
          const IconComponent = iconMap[category.icon as keyof typeof iconMap] || Code

          return (
            <Link key={category.id} href={`/tools?category=${category.slug}`}>
              <Card className="hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-primary/10 rounded-lg">
                        <IconComponent className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-xl">{category.name}</CardTitle>
                      </div>
                    </div>
                    <Badge variant="secondary">{category.toolCount} tools</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">{category.description}</CardDescription>
                </CardContent>
              </Card>
            </Link>
          )
        })}
      </div>
    </div>
  )
}
