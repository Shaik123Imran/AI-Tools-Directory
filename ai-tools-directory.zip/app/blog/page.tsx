import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CalendarDays, Clock, ArrowRight } from "lucide-react"

// Mock blog data - replace with actual Supabase data when blog feature is implemented
const blogPosts = [
  {
    id: 1,
    title: "Top 10 Free AI Tools Every Student Should Know",
    slug: "top-10-free-ai-tools-students",
    excerpt: "Discover the best free AI tools that can help students with research, writing, coding, and productivity.",
    author: "AI Tools Team",
    publishedAt: "2024-01-15",
    readTime: "5 min read",
    category: "Education",
    featured: true,
  },
  {
    id: 2,
    title: "Best AI Coding Assistants for Developers in 2024",
    slug: "best-ai-coding-assistants-2024",
    excerpt: "Compare the top AI coding assistants and find the perfect one for your development workflow.",
    author: "Tech Writer",
    publishedAt: "2024-01-12",
    readTime: "8 min read",
    category: "Development",
    featured: false,
  },
  {
    id: 3,
    title: "How AI is Revolutionizing Content Creation",
    slug: "ai-revolutionizing-content-creation",
    excerpt: "Explore how AI tools are changing the landscape of content creation and what it means for creators.",
    author: "Content Expert",
    publishedAt: "2024-01-10",
    readTime: "6 min read",
    category: "Content",
    featured: false,
  },
]

export default function BlogPage() {
  const featuredPost = blogPosts.find((post) => post.featured)
  const regularPosts = blogPosts.filter((post) => !post.featured)

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">AI Tools Blog</h1>
        <p className="text-muted-foreground">Stay updated with the latest AI tools, trends, and insights</p>
      </div>

      {/* Featured Post */}
      {featuredPost && (
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Featured Article</h2>
          <Card className="overflow-hidden hover:shadow-lg transition-shadow">
            <div className="md:flex">
              <div className="md:w-1/3 bg-gradient-to-br from-primary/10 to-secondary/10 p-8 flex items-center justify-center">
                <div className="text-center">
                  <Badge className="mb-4">{featuredPost.category}</Badge>
                  <div className="text-4xl font-bold text-primary">Featured</div>
                </div>
              </div>
              <div className="md:w-2/3 p-6">
                <CardHeader className="p-0 mb-4">
                  <CardTitle className="text-2xl mb-2">
                    <Link href={`/blog/${featuredPost.slug}`} className="hover:text-primary transition-colors">
                      {featuredPost.title}
                    </Link>
                  </CardTitle>
                  <CardDescription className="text-base">{featuredPost.excerpt}</CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                    <div className="flex items-center space-x-4">
                      <span>By {featuredPost.author}</span>
                      <div className="flex items-center space-x-1">
                        <CalendarDays className="h-4 w-4" />
                        <span>{new Date(featuredPost.publishedAt).toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="h-4 w-4" />
                        <span>{featuredPost.readTime}</span>
                      </div>
                    </div>
                  </div>
                  <Link
                    href={`/blog/${featuredPost.slug}`}
                    className="inline-flex items-center text-primary hover:underline"
                  >
                    Read More
                    <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </CardContent>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Regular Posts */}
      <div>
        <h2 className="text-2xl font-bold mb-6">Latest Articles</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {regularPosts.map((post) => (
            <Card key={post.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="outline">{post.category}</Badge>
                  <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    <span>{post.readTime}</span>
                  </div>
                </div>
                <CardTitle className="text-xl">
                  <Link href={`/blog/${post.slug}`} className="hover:text-primary transition-colors">
                    {post.title}
                  </Link>
                </CardTitle>
                <CardDescription>{post.excerpt}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <span>By {post.author}</span>
                  <div className="flex items-center space-x-1">
                    <CalendarDays className="h-3 w-3" />
                    <span>{new Date(post.publishedAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Coming Soon Notice */}
      <div className="mt-12 text-center">
        <Card className="bg-muted/30">
          <CardContent className="pt-8 pb-8">
            <h3 className="text-xl font-semibold mb-2">More Articles Coming Soon!</h3>
            <p className="text-muted-foreground">
              We're working on bringing you more insightful articles about AI tools and trends.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
