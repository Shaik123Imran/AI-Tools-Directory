import { notFound } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ExternalLink, Star, ArrowLeft, CheckCircle, XCircle, AlertCircle } from "lucide-react"
import { supabase, isSupabaseConfigured } from "@/lib/supabase"
import { mockTools } from "@/lib/mock-data"

interface ToolPageProps {
  params: {
    slug: string
  }
}

export default async function ToolPage({ params }: ToolPageProps) {
  let tool = null

  if (isSupabaseConfigured()) {
    const { data } = await supabase
      .from("tools")
      .select(`
        *,
        categories (*)
      `)
      .eq("slug", params.slug)
      .eq("is_approved", true)
      .single()

    tool = data
  } else {
    // Use mock data when Supabase is not configured
    tool = mockTools.find((t) => t.slug === params.slug)
  }

  if (!tool) {
    notFound()
  }

  const getPricingColor = (pricing: string) => {
    switch (pricing) {
      case "Free":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "Freemium":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      case "Paid":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Back Button */}
      <Button asChild variant="ghost" className="mb-6">
        <Link href="/tools">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Tools
        </Link>
      </Button>

      {!isSupabaseConfigured() && (
        <Alert className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Demo mode: Showing sample data. Configure Supabase to access the full database.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          {/* Header */}
          <div className="space-y-4">
            <div className="flex items-start space-x-4">
              {tool.logo_url && (
                <Image
                  src={tool.logo_url || "/placeholder.svg"}
                  alt={`${tool.name} logo`}
                  width={80}
                  height={80}
                  className="rounded-xl"
                />
              )}
              <div className="flex-1">
                <h1 className="text-3xl font-bold mb-2">{tool.name}</h1>
                <p className="text-xl text-muted-foreground mb-4">{tool.short_description}</p>
                <div className="flex items-center space-x-4">
                  <Badge className={getPricingColor(tool.pricing)}>{tool.pricing}</Badge>
                  {tool.rating && (
                    <div className="flex items-center space-x-1">
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      <span className="font-medium">{tool.rating}</span>
                    </div>
                  )}
                  {tool.categories && <Badge variant="outline">{tool.categories.name}</Badge>}
                </div>
              </div>
            </div>
          </div>

          {/* Description */}
          <Card>
            <CardHeader>
              <CardTitle>About {tool.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">{tool.description}</p>
            </CardContent>
          </Card>

          {/* Features */}
          {tool.features && tool.features.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Key Features</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {tool.features.map((feature, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          {/* Pros & Cons */}
          {((tool.pros && tool.pros.length > 0) || (tool.cons && tool.cons.length > 0)) && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {tool.pros && tool.pros.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-green-600">Pros</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {tool.pros.map((pro, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <CheckCircle className="h-4 w-4 text-green-500 mt-1 flex-shrink-0" />
                          <span className="text-sm">{pro}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )}

              {tool.cons && tool.cons.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-red-600">Cons</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {tool.cons.map((con, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <XCircle className="h-4 w-4 text-red-500 mt-1 flex-shrink-0" />
                          <span className="text-sm">{con}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          {/* Tags */}
          {tool.tags && tool.tags.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Tags</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {tool.tags.map((tag) => (
                    <Badge key={tag} variant="secondary">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* CTA Card */}
          <Card>
            <CardHeader>
              <CardTitle>Try {tool.name}</CardTitle>
              <CardDescription>Visit the official website to get started</CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild className="w-full" size="lg">
                <Link href={tool.website_url} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="mr-2 h-4 w-4" />
                  Visit Website
                </Link>
              </Button>
            </CardContent>
          </Card>

          {/* Tool Info */}
          <Card>
            <CardHeader>
              <CardTitle>Tool Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-medium mb-1">Category</h4>
                <p className="text-sm text-muted-foreground">{tool.categories?.name || "Uncategorized"}</p>
              </div>
              <Separator />
              <div>
                <h4 className="font-medium mb-1">Pricing Model</h4>
                <Badge className={getPricingColor(tool.pricing)}>{tool.pricing}</Badge>
              </div>
              {tool.rating && (
                <>
                  <Separator />
                  <div>
                    <h4 className="font-medium mb-1">Rating</h4>
                    <div className="flex items-center space-x-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm">{tool.rating} out of 5</span>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {/* Demo Video */}
          {tool.demo_video_url && (
            <Card>
              <CardHeader>
                <CardTitle>Demo Video</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="aspect-video">
                  <iframe src={tool.demo_video_url} className="w-full h-full rounded-lg" allowFullScreen />
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
