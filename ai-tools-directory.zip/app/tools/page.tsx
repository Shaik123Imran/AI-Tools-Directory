"use client"

import { useState, useEffect, useCallback } from "react"
import { useSearchParams } from "next/navigation"
import { ToolCard } from "@/components/tool-card"
import { SearchFilters } from "@/components/search-filters"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { supabase, isSupabaseConfigured } from "@/lib/supabase"
import { mockTools, mockCategories } from "@/lib/mock-data"
import { AlertCircle } from "lucide-react"
import type { Database } from "@/lib/supabase"

type Tool = Database["public"]["Tables"]["tools"]["Row"] & {
  categories?: Database["public"]["Tables"]["categories"]["Row"]
}

const TOOLS_PER_PAGE = 12

export default function ToolsPage() {
  const searchParams = useSearchParams()
  const [tools, setTools] = useState<Tool[]>([])
  const [loading, setLoading] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const [hasMore, setHasMore] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const [filters, setFilters] = useState({
    search: searchParams.get("search") || "",
    category: searchParams.get("category") || "",
    pricing: searchParams.get("pricing") || "",
    sortBy: searchParams.get("sort") || "name",
  })

  const fetchTools = useCallback(
    async (page = 1, reset = false) => {
      if (page === 1) setLoading(true)
      else setLoadingMore(true)

      try {
        if (!isSupabaseConfigured()) {
          // Use mock data when Supabase is not configured
          let filteredTools = [...mockTools]

          // Apply search filter
          if (filters.search) {
            const searchLower = filters.search.toLowerCase()
            filteredTools = filteredTools.filter(
              (tool) =>
                tool.name.toLowerCase().includes(searchLower) ||
                tool.description.toLowerCase().includes(searchLower) ||
                (tool.short_description && tool.short_description.toLowerCase().includes(searchLower)),
            )
          }

          // Apply category filter
          if (filters.category) {
            const category = mockCategories.find((cat) => cat.slug === filters.category)
            if (category) {
              filteredTools = filteredTools.filter((tool) => tool.category_id === category.id)
            }
          }

          // Apply pricing filter
          if (filters.pricing) {
            filteredTools = filteredTools.filter((tool) => tool.pricing === filters.pricing)
          }

          // Apply sorting
          switch (filters.sortBy) {
            case "rating":
              filteredTools.sort((a, b) => (b.rating || 0) - (a.rating || 0))
              break
            case "created_at":
              filteredTools.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
              break
            default:
              filteredTools.sort((a, b) => a.name.localeCompare(b.name))
          }

          // Simulate pagination
          const from = (page - 1) * TOOLS_PER_PAGE
          const to = from + TOOLS_PER_PAGE
          const paginatedTools = filteredTools.slice(from, to)

          if (reset || page === 1) {
            setTools(paginatedTools)
          } else {
            setTools((prev) => [...prev, ...paginatedTools])
          }

          setHasMore(to < filteredTools.length)
        } else {
          // Use Supabase data
          let query = supabase
            .from("tools")
            .select(`
            *,
            categories (*)
          `)
            .eq("is_approved", true)

          // Apply filters
          if (filters.search) {
            query = query.or(
              `name.ilike.%${filters.search}%,description.ilike.%${filters.search}%,short_description.ilike.%${filters.search}%`,
            )
          }

          if (filters.category) {
            const { data: categoryData } = await supabase
              .from("categories")
              .select("id")
              .eq("slug", filters.category)
              .single()

            if (categoryData) {
              query = query.eq("category_id", categoryData.id)
            }
          }

          if (filters.pricing) {
            query = query.eq("pricing", filters.pricing)
          }

          // Apply sorting
          switch (filters.sortBy) {
            case "rating":
              query = query.order("rating", { ascending: false, nullsLast: true })
              break
            case "created_at":
              query = query.order("created_at", { ascending: false })
              break
            default:
              query = query.order("name", { ascending: true })
          }

          // Pagination
          const from = (page - 1) * TOOLS_PER_PAGE
          const to = from + TOOLS_PER_PAGE - 1
          query = query.range(from, to)

          const { data, error } = await query

          if (error) throw error

          if (reset || page === 1) {
            setTools(data || [])
          } else {
            setTools((prev) => [...prev, ...(data || [])])
          }

          setHasMore((data || []).length === TOOLS_PER_PAGE)
        }
      } catch (error) {
        console.error("Error fetching tools:", error)
      } finally {
        setLoading(false)
        setLoadingMore(false)
      }
    },
    [filters],
  )

  useEffect(() => {
    setCurrentPage(1)
    fetchTools(1, true)
  }, [fetchTools])

  const handleFiltersChange = useCallback((newFilters: typeof filters) => {
    setFilters(newFilters)
  }, [])

  const loadMore = () => {
    const nextPage = currentPage + 1
    setCurrentPage(nextPage)
    fetchTools(nextPage)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">AI Tools Directory</h1>
        <p className="text-muted-foreground">Discover and explore the best AI tools for your needs</p>
      </div>

      {!isSupabaseConfigured() && (
        <Alert className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Demo mode: Showing sample data. Configure Supabase to access the full database of AI tools.
          </AlertDescription>
        </Alert>
      )}

      <div className="mb-8">
        <SearchFilters onFiltersChange={handleFiltersChange} initialFilters={filters} />
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="space-y-4">
              <Skeleton className="h-48 w-full rounded-lg" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
            </div>
          ))}
        </div>
      ) : (
        <>
          {tools.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground text-lg">No tools found matching your criteria.</p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                {tools.map((tool) => (
                  <ToolCard key={tool.id} tool={tool} />
                ))}
              </div>

              {hasMore && (
                <div className="text-center">
                  <Button onClick={loadMore} disabled={loadingMore} variant="outline" size="lg">
                    {loadingMore ? "Loading..." : "Load More Tools"}
                  </Button>
                </div>
              )}
            </>
          )}
        </>
      )}
    </div>
  )
}
