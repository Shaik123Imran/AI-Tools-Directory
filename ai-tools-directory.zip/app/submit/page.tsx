"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/hooks/use-toast"
import { Loader2, CheckCircle, AlertCircle } from "lucide-react"
import { supabase, isSupabaseConfigured } from "@/lib/supabase"
import { mockCategories } from "@/lib/mock-data"
import type { Database } from "@/lib/supabase"

type Category = Database["public"]["Tables"]["categories"]["Row"]

export default function SubmitToolPage() {
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const { toast } = useToast()

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    website_url: "",
    category_id: "",
    pricing: "",
    submitter_name: "",
    submitter_email: "",
  })

  useEffect(() => {
    fetchCategories()
  }, [])

  const fetchCategories = async () => {
    if (isSupabaseConfigured()) {
      const { data } = await supabase.from("categories").select("*").order("name")
      if (data) {
        setCategories(data)
      }
    } else {
      // Use mock data when Supabase is not configured
      setCategories(mockCategories)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      if (!isSupabaseConfigured()) {
        // Simulate submission when Supabase is not configured
        await new Promise((resolve) => setTimeout(resolve, 1000))
        setSubmitted(true)
        toast({
          title: "Demo submission received!",
          description: "This is a demo. Configure Supabase to enable real submissions.",
        })
        return
      }

      const { error } = await supabase.from("submissions").insert([
        {
          name: formData.name,
          description: formData.description,
          website_url: formData.website_url,
          category_id: formData.category_id ? Number.parseInt(formData.category_id) : null,
          pricing: formData.pricing,
          submitter_name: formData.submitter_name,
          submitter_email: formData.submitter_email,
        },
      ])

      if (error) throw error

      setSubmitted(true)
      toast({
        title: "Tool submitted successfully!",
        description: "Thank you for your submission. We'll review it and get back to you soon.",
      })
    } catch (error) {
      console.error("Error submitting tool:", error)
      toast({
        title: "Error submitting tool",
        description: "Please try again later.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  if (submitted) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-2xl mx-auto text-center">
          <Card>
            <CardContent className="pt-8 pb-8">
              <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
              <h1 className="text-2xl font-bold mb-4">Thank You!</h1>
              <p className="text-muted-foreground mb-6">
                {isSupabaseConfigured()
                  ? "Your tool submission has been received. Our team will review it and get back to you within 2-3 business days."
                  : "This was a demo submission. Configure Supabase to enable real tool submissions."}
              </p>
              <Button
                onClick={() => {
                  setSubmitted(false)
                  setFormData({
                    name: "",
                    description: "",
                    website_url: "",
                    category_id: "",
                    pricing: "",
                    submitter_name: "",
                    submitter_email: "",
                  })
                }}
              >
                Submit Another Tool
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-2xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-4">Submit an AI Tool</h1>
          <p className="text-muted-foreground">
            Know an amazing AI tool that should be featured? Submit it here and help the community discover new and
            useful AI solutions.
          </p>
        </div>

        {!isSupabaseConfigured() && (
          <Alert className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Demo mode: Submissions won't be saved. Configure Supabase to enable real tool submissions.
            </AlertDescription>
          </Alert>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Tool Information</CardTitle>
            <CardDescription>
              Please provide detailed information about the AI tool you'd like to submit.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Tool Name */}
              <div className="space-y-2">
                <Label htmlFor="name">Tool Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                  placeholder="e.g., ChatGPT, GitHub Copilot"
                  required
                />
              </div>

              {/* Description */}
              <div className="space-y-2">
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange("description", e.target.value)}
                  placeholder="Provide a detailed description of what this tool does and how it helps users..."
                  rows={4}
                  required
                />
              </div>

              {/* Website URL */}
              <div className="space-y-2">
                <Label htmlFor="website_url">Website URL *</Label>
                <Input
                  id="website_url"
                  type="url"
                  value={formData.website_url}
                  onChange={(e) => handleInputChange("website_url", e.target.value)}
                  placeholder="https://example.com"
                  required
                />
              </div>

              {/* Category */}
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select value={formData.category_id} onValueChange={(value) => handleInputChange("category_id", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.id.toString()}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Pricing */}
              <div className="space-y-2">
                <Label htmlFor="pricing">Pricing Model *</Label>
                <Select
                  value={formData.pricing}
                  onValueChange={(value) => handleInputChange("pricing", value)}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select pricing model" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Free">Free</SelectItem>
                    <SelectItem value="Freemium">Freemium</SelectItem>
                    <SelectItem value="Paid">Paid</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Submitter Information */}
              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold mb-4">Your Information</h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="submitter_name">Your Name</Label>
                    <Input
                      id="submitter_name"
                      value={formData.submitter_name}
                      onChange={(e) => handleInputChange("submitter_name", e.target.value)}
                      placeholder="John Doe"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="submitter_email">Your Email</Label>
                    <Input
                      id="submitter_email"
                      type="email"
                      value={formData.submitter_email}
                      onChange={(e) => handleInputChange("submitter_email", e.target.value)}
                      placeholder="john@example.com"
                    />
                  </div>
                </div>
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Submit Tool for Review
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="mt-8 text-center text-sm text-muted-foreground">
          <p>
            By submitting a tool, you agree that the information provided is accurate and that you have the right to
            submit this tool for review.
          </p>
        </div>
      </div>
    </div>
  )
}
