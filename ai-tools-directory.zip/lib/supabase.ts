import { createClient } from "@supabase/supabase-js"

// Check if we're in a browser environment
const isBrowser = typeof window !== "undefined"

// Get environment variables with fallbacks
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""

// Create a mock client for development when env vars are missing
const createMockClient = () => ({
  from: (table: string) => ({
    select: () => ({ data: [], error: null }),
    insert: () => ({ data: null, error: { message: "Supabase not configured" } }),
    update: () => ({ data: null, error: { message: "Supabase not configured" } }),
    delete: () => ({ data: null, error: { message: "Supabase not configured" } }),
    eq: () => ({ data: [], error: null }),
    order: () => ({ data: [], error: null }),
    limit: () => ({ data: [], error: null }),
    range: () => ({ data: [], error: null }),
    single: () => ({ data: null, error: { message: "Supabase not configured" } }),
    or: () => ({ data: [], error: null }),
  }),
})

// Create Supabase client or mock client
export const supabase =
  supabaseUrl && supabaseAnonKey ? createClient(supabaseUrl, supabaseAnonKey) : (createMockClient() as any)

// Helper function to check if Supabase is configured
export const isSupabaseConfigured = () => {
  return !!(supabaseUrl && supabaseAnonKey)
}

export type Database = {
  public: {
    Tables: {
      categories: {
        Row: {
          id: number
          name: string
          slug: string
          description: string | null
          icon: string | null
          created_at: string
        }
        Insert: {
          id?: number
          name: string
          slug: string
          description?: string | null
          icon?: string | null
          created_at?: string
        }
        Update: {
          id?: number
          name?: string
          slug?: string
          description?: string | null
          icon?: string | null
          created_at?: string
        }
      }
      tools: {
        Row: {
          id: number
          name: string
          slug: string
          description: string
          short_description: string | null
          website_url: string
          logo_url: string | null
          category_id: number | null
          pricing: "Free" | "Freemium" | "Paid"
          rating: number | null
          tags: string[] | null
          features: string[] | null
          pros: string[] | null
          cons: string[] | null
          demo_video_url: string | null
          screenshots: string[] | null
          is_featured: boolean | null
          is_approved: boolean | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: number
          name: string
          slug: string
          description: string
          short_description?: string | null
          website_url: string
          logo_url?: string | null
          category_id?: number | null
          pricing: "Free" | "Freemium" | "Paid"
          rating?: number | null
          tags?: string[] | null
          features?: string[] | null
          pros?: string[] | null
          cons?: string[] | null
          demo_video_url?: string | null
          screenshots?: string[] | null
          is_featured?: boolean | null
          is_approved?: boolean | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: number
          name?: string
          slug?: string
          description?: string
          short_description?: string | null
          website_url?: string
          logo_url?: string | null
          category_id?: number | null
          pricing?: "Free" | "Freemium" | "Paid"
          rating?: number | null
          tags?: string[] | null
          features?: string[] | null
          pros?: string[] | null
          cons?: string[] | null
          demo_video_url?: string | null
          screenshots?: string[] | null
          is_featured?: boolean | null
          is_approved?: boolean | null
          created_at?: string
          updated_at?: string
        }
      }
      submissions: {
        Row: {
          id: number
          name: string
          description: string
          website_url: string
          category_id: number | null
          pricing: string
          submitter_email: string | null
          submitter_name: string | null
          status: "pending" | "approved" | "rejected"
          created_at: string
        }
        Insert: {
          id?: number
          name: string
          description: string
          website_url: string
          category_id?: number | null
          pricing: string
          submitter_email?: string | null
          submitter_name?: string | null
          status?: "pending" | "approved" | "rejected"
          created_at?: string
        }
        Update: {
          id?: number
          name?: string
          description?: string
          website_url?: string
          category_id?: number | null
          pricing?: string
          submitter_email?: string | null
          submitter_name?: string | null
          status?: "pending" | "approved" | "rejected"
          created_at?: string
        }
      }
    }
  }
}
